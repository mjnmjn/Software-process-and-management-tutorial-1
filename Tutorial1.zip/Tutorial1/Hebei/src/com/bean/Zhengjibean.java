package com.bean;

public class Zhengjibean 
{
	private int id;
	private int status;
	private String createdate;
	private int userid;
	private String jiname;
	private String guikou;
	private String tongxundizhi;
	private String suozaidiyu;
	private String wangzhi;
	private String dianzixinxiang;
	private String farendaibiao;
	private String youzhengbianma;
	private String lianxi;
	private String dianhua;
	private String shouji;

	
	private String chuangzhen;
	private String jigoushuxing;
	private String jigoujianjie;
	private String jishuxuqiuname;
	private String xuqiuqianyear;
	private String xuqiuhouyear;
	private String xuqiugaishu;
	private String guanjian1;
	private String guanjian2;
	private String guanjian3;
	private String guanjian4;
	private String guanjian5;
	private String jine;
	private String xuqiujiejuefangshi;
	private String hezuodanwei;
	private String kejihuodongleixing;
	private String xuekenfenlei;
	private String twoxueke;
	private String lingyu;
	private String hangye;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getCreatedate() {
		return createdate;
	}
	public void setCreatedate(String createdate) {
		this.createdate = createdate;
	}
	public String getTwoxueke() {
		return twoxueke;
	}
	public void setTwoxueke(String twoxueke) {
		this.twoxueke = twoxueke;
	}
	public String getXuqiugaishu() {
		return xuqiugaishu;
	}
	public void setXuqiugaishu(String xuqiugaishu) {
		this.xuqiugaishu = xuqiugaishu;
	}
	
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getHangye() {
		return hangye;
	}
	public void setHangye(String hangye) {
		this.hangye = hangye;
	}
	public String getJiname() {
		return jiname;
	}
	public void setJiname(String jiname) {
		this.jiname = jiname;
	}
	public String getGuikou() {
		return guikou;
	}
	public void setGuikou(String guikou) {
		this.guikou = guikou;
	}
	public String getTongxundizhi() {
		return tongxundizhi;
	}
	public void setTongxundizhi(String tongxundizhi) {
		this.tongxundizhi = tongxundizhi;
	}
	public String getSuozaidiyu() {
		return suozaidiyu;
	}
	public void setSuozaidiyu(String suozaidiyu) {
		this.suozaidiyu = suozaidiyu;
	}
	public String getWangzhi() {
		return wangzhi;
	}
	public void setWangzhi(String wangzhi) {
		this.wangzhi = wangzhi;
	}
	public String getDianzixinxiang() {
		return dianzixinxiang;
	}
	public void setDianzixinxiang(String dianzixinxiang) {
		this.dianzixinxiang = dianzixinxiang;
	}
	public String getFarendaibiao() {
		return farendaibiao;
	}
	public void setFarendaibiao(String farendaibiao) {
		this.farendaibiao = farendaibiao;
	}
	public String getYouzhengbianma() {
		return youzhengbianma;
	}
	public void setYouzhengbianma(String youzhengbianma) {
		this.youzhengbianma = youzhengbianma;
	}
	public String getLianxi() {
		return lianxi;
	}
	public void setLianxi(String lianxi) {
		this.lianxi = lianxi;
	}
	public String getDianhua() {
		return dianhua;
	}
	public void setDianhua(String dianhua) {
		this.dianhua = dianhua;
	}
	public String getShouji() {
		return shouji;
	}
	public void setShouji(String shouji) {
		this.shouji = shouji;
	}
	public String getChuangzhen() {
		return chuangzhen;
	}
	public void setChuangzhen(String chuangzhen) {
		this.chuangzhen = chuangzhen;
	}
	public String getJigoushuxing() {
		return jigoushuxing;
	}
	public void setJigoushuxing(String jigoushuxing) {
		this.jigoushuxing = jigoushuxing;
	}
	public String getJigoujianjie() {
		return jigoujianjie;
	}
	public void setJigoujianjie(String jigoujianjie) {
		this.jigoujianjie = jigoujianjie;
	}
	public String getJishuxuqiuname() {
		return jishuxuqiuname;
	}
	public void setJishuxuqiuname(String jishuxuqiuname) {
		this.jishuxuqiuname = jishuxuqiuname;
	}
	public String getXuqiuqianyear() {
		return xuqiuqianyear;
	}
	public void setXuqiuqianyear(String xuqiuqianyear) {
		this.xuqiuqianyear = xuqiuqianyear;
	}
	public String getXuqiuhouyear() {
		return xuqiuhouyear;
	}
	public void setXuqiuhouyear(String xuqiuhouyear) {
		this.xuqiuhouyear = xuqiuhouyear;
	}
	
	public String getGuanjian1() {
		return guanjian1;
	}
	public void setGuanjian1(String guanjian1) {
		this.guanjian1 = guanjian1;
	}
	public String getGuanjian2() {
		return guanjian2;
	}
	public void setGuanjian2(String guanjian2) {
		this.guanjian2 = guanjian2;
	}
	public String getGuanjian3() {
		return guanjian3;
	}
	public void setGuanjian3(String guanjian3) {
		this.guanjian3 = guanjian3;
	}
	public String getGuanjian4() {
		return guanjian4;
	}
	public void setGuanjian4(String guanjian4) {
		this.guanjian4 = guanjian4;
	}
	public String getGuanjian5() {
		return guanjian5;
	}
	public void setGuanjian5(String guanjian5) {
		this.guanjian5 = guanjian5;
	}
	public String getJine() {
		return jine;
	}
	public void setJine(String jine) {
		this.jine = jine;
	}
	public String getXuqiujiejuefangshi() {
		return xuqiujiejuefangshi;
	}
	public void setXuqiujiejuefangshi(String xuqiujiejuefangshi) {
		this.xuqiujiejuefangshi = xuqiujiejuefangshi;
	}
	public String getHezuodanwei() {
		return hezuodanwei;
	}
	public void setHezuodanwei(String hezuodanwei) {
		this.hezuodanwei = hezuodanwei;
	}
	public String getKejihuodongleixing() {
		return kejihuodongleixing;
	}
	public void setKejihuodongleixing(String kejihuodongleixing) {
		this.kejihuodongleixing = kejihuodongleixing;
	}
	public String getXuekenfenlei() {
		return xuekenfenlei;
	}
	public void setXuekenfenlei(String xuekenfenlei) {
		this.xuekenfenlei = xuekenfenlei;
	}
	public String getLingyu() {
		return lingyu;
	}
	public void setLingyu(String lingyu) {
		this.lingyu = lingyu;
	}
	@Override
	public String toString() {
		return "Zhengjibean [id=" + id + ", status=" + status + ", createdate=" + createdate + ", userid=" + userid
				+ ", jiname=" + jiname + ", guikou=" + guikou + ", tongxundizhi=" + tongxundizhi + ", suozaidiyu="
				+ suozaidiyu + ", wangzhi=" + wangzhi + ", dianzixinxiang=" + dianzixinxiang + ", farendaibiao="
				+ farendaibiao + ", youzhengbianma=" + youzhengbianma + ", lianxi=" + lianxi + ", dianhua=" + dianhua
				+ ", shouji=" + shouji + ", chuangzhen=" + chuangzhen + ", jigoushuxing=" + jigoushuxing
				+ ", jigoujianjie=" + jigoujianjie + ", jishuxuqiuname=" + jishuxuqiuname + ", xuqiuqianyear="
				+ xuqiuqianyear + ", xuqiuhouyear=" + xuqiuhouyear + ", xuqiugaishu=" + xuqiugaishu + ", guanjian1="
				+ guanjian1 + ", guanjian2=" + guanjian2 + ", guanjian3=" + guanjian3 + ", guanjian4=" + guanjian4
				+ ", guanjian5=" + guanjian5 + ", jine=" + jine + ", xuqiujiejuefangshi=" + xuqiujiejuefangshi
				+ ", hezuodanwei=" + hezuodanwei + ", kejihuodongleixing=" + kejihuodongleixing + ", xuekenfenlei="
				+ xuekenfenlei + ", twoxueke=" + twoxueke + ", lingyu=" + lingyu + ", hangye=" + hangye + "]";
	}
	
	
	
	

}
