package com.bean;

public class Tiaojianbean {
	private int id;
	private String xuqiuname;
	private String xuqiunamefangshi;
	private String guanjian;
	private String guanjianfangshi;
	private String jigoushuxing;
	private String xuqiujiejuefanghsi;
	private String kejihuodong;
	private String time;
	private String time1;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getXuqiuname() {
		return xuqiuname;
	}
	public void setXuqiuname(String xuqiuname) {
		this.xuqiuname = xuqiuname;
	}
	public String getXuqiunamefangshi() {
		return xuqiunamefangshi;
	}
	public void setXuqiunamefangshi(String xuqiunamefangshi) {
		this.xuqiunamefangshi = xuqiunamefangshi;
	}
	public String getGuanjian() {
		return guanjian;
	}
	public void setGuanjian(String guanjian) {
		this.guanjian = guanjian;
	}
	
	public String getGuanjianfangshi() {
		return guanjianfangshi;
	}
	public void setGuanjianfangshi(String guanjianfangshi) {
		this.guanjianfangshi = guanjianfangshi;
	}
	public String getJigoushuxing() {
		return jigoushuxing;
	}
	public void setJigoushuxing(String jigoushuxing) {
		this.jigoushuxing = jigoushuxing;
	}
	public String getXuqiujiejuefanghsi() {
		return xuqiujiejuefanghsi;
	}
	public void setXuqiujiejuefanghsi(String xuqiujiejuefanghsi) {
		this.xuqiujiejuefanghsi = xuqiujiejuefanghsi;
	}
	public String getKejihuodong() {
		return kejihuodong;
	}
	public void setKejihuodong(String kejihuodong) {
		this.kejihuodong = kejihuodong;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getTime1() {
		return time1;
	}
	public void setTime1(String time1) {
		this.time1 = time1;
	}
	@Override
	public String toString() {
		return "Tiaojianbean [id=" + id + ", xuqiuname=" + xuqiuname + ", xuqiunamefangshi=" + xuqiunamefangshi
				+ ", guanjian=" + guanjian + ", guanjianfangshi=" + guanjianfangshi + ", jigoushuxing=" + jigoushuxing
				+ ", xuqiujiejuefanghsi=" + xuqiujiejuefanghsi + ", kejihuodong=" + kejihuodong + ", time=" + time
				+ ", time1=" + time1 + "]";
	}
	
	
	

}
