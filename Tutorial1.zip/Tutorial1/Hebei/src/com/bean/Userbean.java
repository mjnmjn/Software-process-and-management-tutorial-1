package com.bean;

public class Userbean 
{
	private int id;//����id
	private String shenfen;
	private String username;//�����û���
	private String password;//����
	private String name;
	private String shenfenhao;
	private String shi;
	private String danwei;
	private String zhuanye;
	private String hangye;
	private String jiaoyu;
	private String zhicheng;
	private String tongxundizhi;
	private String youzhengbianma;
	private String shouji;
	private String dianhua;
	private String youxiang;
	
	public String getShenfen() {
		return shenfen;
	}
	public void setShenfen(String shenfen) {
		this.shenfen = shenfen;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShenfenhao() {
		return shenfenhao;
	}
	public void setShenfenhao(String shenfenhao) {
		this.shenfenhao = shenfenhao;
	}
	public String getShi() {
		return shi;
	}
	public void setShi(String shi) {
		this.shi = shi;
	}
	public String getDanwei() {
		return danwei;
	}
	public void setDanwei(String danwei) {
		this.danwei = danwei;
	}
	public String getZhuanye() {
		return zhuanye;
	}
	public void setZhuanye(String zhuanye) {
		this.zhuanye = zhuanye;
	}
	public String getHangye() {
		return hangye;
	}
	public void setHangye(String hangye) {
		this.hangye = hangye;
	}
	public String getJiaoyu() {
		return jiaoyu;
	}
	public void setJiaoyu(String jiaoyu) {
		this.jiaoyu = jiaoyu;
	}
	public String getZhicheng() {
		return zhicheng;
	}
	public void setZhicheng(String zhicheng) {
		this.zhicheng = zhicheng;
	}
	public String getTongxundizhi() {
		return tongxundizhi;
	}
	public void setTongxundizhi(String tongxundizhi) {
		this.tongxundizhi = tongxundizhi;
	}
	public String getYouzhengbianma() {
		return youzhengbianma;
	}
	public void setYouzhengbianma(String youzhengbianma) {
		this.youzhengbianma = youzhengbianma;
	}
	public String getShouji() {
		return shouji;
	}
	public void setShouji(String shouji) {
		this.shouji = shouji;
	}
	public String getDianhua() {
		return dianhua;
	}
	public void setDianhua(String dianhua) {
		this.dianhua = dianhua;
	}
	public String getYouxiang() {
		return youxiang;
	}
	public void setYouxiang(String youxiang) {
		this.youxiang = youxiang;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Userbean [id=" + id + ", shenfen=" + shenfen + ", username=" + username + ", password=" + password
				+ ", name=" + name + ", shenfenhao=" + shenfenhao + ", shi=" + shi + ", danwei=" + danwei + ", zhuanye="
				+ zhuanye + ", hangye=" + hangye + ", jiaoyu=" + jiaoyu + ", zhicheng=" + zhicheng + ", tongxundizhi="
				+ tongxundizhi + ", youzhengbianma=" + youzhengbianma + ", shouji=" + shouji + ", dianhua=" + dianhua
				+ ", youxiang=" + youxiang + ", getShenfen()=" + getShenfen() + ", getName()=" + getName()
				+ ", getShenfenhao()=" + getShenfenhao() + ", getShi()=" + getShi() + ", getDanwei()=" + getDanwei()
				+ ", getZhuanye()=" + getZhuanye() + ", getHangye()=" + getHangye() + ", getJiaoyu()=" + getJiaoyu()
				+ ", getZhicheng()=" + getZhicheng() + ", getTongxundizhi()=" + getTongxundizhi()
				+ ", getYouzhengbianma()=" + getYouzhengbianma() + ", getShouji()=" + getShouji() + ", getDianhua()="
				+ getDianhua() + ", getYouxiang()=" + getYouxiang() + ", getId()=" + getId() + ", getUsername()="
				+ getUsername() + ", getPassword()=" + getPassword() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
	

}
