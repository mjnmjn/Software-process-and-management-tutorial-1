package com.bean;

public class Tuihuibean 
{
	private int id;
	private int zhengjiid;
	private String tuihui;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getZhengjiid() {
		return zhengjiid;
	}
	public void setZhengjiid(int zhengjiid) {
		this.zhengjiid = zhengjiid;
	}
	public String getTuihui() {
		return tuihui;
	}
	public void setTuihui(String tuihui) {
		this.tuihui = tuihui;
	}
	

}
