
jQuery(function(){
	jQuery("#authority").load("clickmenu");
});